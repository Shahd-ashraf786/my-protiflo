document.getElementById('year').textContent = new Date().getFullYear();
const io = new IntersectionObserver((entries) => {
  entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); io.unobserve(e.target); } });
}, { threshold: 0.15 });
document.querySelectorAll('.reveal').forEach(el => io.observe(el));
// close mobile menu after click
document.querySelectorAll('#navMenu .nav-link').forEach(l => l.addEventListener('click', () => {
  const m = document.getElementById('navMenu');
  if (m.classList.contains('show')) bootstrap.Collapse.getOrCreateInstance(m).hide();
}));
